-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2025 at 12:14 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";



/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentinformationmanagementsystemproject`
--

/*reg 2305000654  */;
/*Name: uwayisenga joselyne*/;
DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddCourse` (`p_courseCode` VARCHAR(10), `p_name` VARCHAR(100), `p_instructor` VARCHAR(100))   BEGIN  
  INSERT INTO Courses (courseCode, name, instructor) 
  VALUES (p_courseCode, p_name, p_instructor);  
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `studentID` int(11) NOT NULL,
  `date` date NOT NULL,
  `attendanceStatus` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`studentID`, `date`, `attendanceStatus`) VALUES
(1, '2025-01-01', 1),
(1, '2025-01-02', 1),
(2, '2025-01-01', 0),
(2, '2025-01-02', 1),
(3, '2025-01-01', 1),
(3, '2025-01-02', 0);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `courseCode` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `instructor` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`courseCode`, `name`, `instructor`) VALUES
('CS101', 'Introduction to Computer Science', 'Dr. Adams'),
('MATH201', 'Advanced Mathematics', 'Prof. Clark'),
('PHYS301', 'Modern Physics', 'Dr. Green');

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `studentID` int(11) NOT NULL,
  `courseCode` varchar(10) NOT NULL,
  `grade` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`studentID`, `courseCode`, `grade`) VALUES
(1, 'CS101', 90),
(2, 'MATH201', 85),
(3, 'PHYS301', 88);

-- --------------------------------------------------------

--
-- Stand-in structure for view `perfectattendance`
-- (See below for the actual view)
--
CREATE TABLE `perfectattendance` (
`studentID` int(11)
,`TotalDays` bigint(21)
);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `studentID` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `major` varchar(100) DEFAULT NULL,
  `year` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`studentID`, `name`, `major`, `year`) VALUES
(1, 'John Doe', 'Computer Science', 1),
(2, 'Jane Smith', 'Mathematics', 2),
(3, 'Emily Johnson', 'Physics', 3);

-- --------------------------------------------------------

--
-- Structure for view `perfectattendance`
--
DROP TABLE IF EXISTS `perfectattendance`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `perfectattendance`  AS SELECT `attendance`.`studentID` AS `studentID`, count(`attendance`.`attendanceStatus`) AS `TotalDays` FROM `attendance` WHERE `attendance`.`attendanceStatus` = 1 GROUP BY `attendance`.`studentID` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`studentID`,`date`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`courseCode`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`studentID`,`courseCode`),
  ADD KEY `courseCode` (`courseCode`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`studentID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`);

--
-- Constraints for table `grades`
--
ALTER TABLE `grades`
  ADD CONSTRAINT `grades_ibfk_1` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`),
  ADD CONSTRAINT `grades_ibfk_2` FOREIGN KEY (`courseCode`) REFERENCES `courses` (`courseCode`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
